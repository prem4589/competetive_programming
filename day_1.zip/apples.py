import math
def check(l):
	maxi=0
	mini=math.inf
	l2=[]
	for i in range(len(l)-1):
		buy=l[i]
		for j in range(i+1,len(l)):
			sell=l[j]
			if(buy<sell):
				if(maxi<sell-buy):
					maxi=sell-buy
			else:
				if(mini>(sell-buy)):
					mini=sell-buy
					l2.append(mini)
					
	if(maxi>0):
		return maxi
	else:
		return max(l2)
n=int(input("enter your array size"))
l=[]
print("enter your elements")
for i in range(n):
	m=int(input())
	l.append(m)
x=check(l)
print("max profit is ",x)
