def check(l):
	
l=[]
n=int(input("enter length of array"))
print("enter the elements")
for i in range(n):
	m=int(input())
	l.append(m)
check(l)
